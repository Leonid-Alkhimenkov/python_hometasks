from hw_2.latex_lib import generate_table, generate_image, gererate_latex_and_pdf

__all__ = ["generate_table", "generate_image", "gererate_latex_and_pdf"]
